const express = require('express');
const router = express.Router();
const Product = require('../models/product');

// Route to add a product
router.post('/', (req, res) => {
  const productData = req.body;
  const newProduct = new Product(productData);

  newProduct.save()
    .then((product) => {
      res.status(201).json(product);
    })
    .catch((error) => {
      res.status(400).json({ error: error.message });
    });
});

// Route to get all products
router.get('/', (req, res) => {
  Product.find()
    .then((products) => {
      res.json(products);
    })
    .catch((error) => {
      res.status(500).json({ error: error.message });
    });
});

// Route to update a product
router.put('/:productId', (req, res) => {
  const productId = req.params.productId;
  Product.findByIdAndUpdate(productId, req.body, { new: true })
    .then((updatedProduct) => {
      if (!updatedProduct) {
        return res.status(404).json({ message: 'Product not found' });
      }
      res.json(updatedProduct);
    })
    .catch((error) => {
      res.status(400).json({ error: error.message });
    });
});

// Route to delete a product
router.delete('/:productId', (req, res) => {
  const productId = req.params.productId;
  Product.findByIdAndRemove(productId)
    .then(() => {
      res.sendStatus(204);
    })
    .catch((error) => {
      res.status(400).json({ error: error.message });
    });
});

// Route to fetch featured products
router.get('/featured', (req, res) => {
  Product.find({ featured: true })
    .then((featuredProducts) => {
      res.json(featuredProducts);
    })
    .catch((error) => {
      res.status(500).json({ error: error.message });
    });
});

// Route to fetch products with a price less than a certain value
router.get('/price/:value', (req, res) => {
  const value = parseFloat(req.params.value);
  Product.find({ price: { $lt: value } })
    .then((products) => {
      res.json(products);
    })
    .catch((error) => {
      res.status(500).json({ error: error.message });
    });
});

// Route to fetch products with a rating higher than a certain value
router.get('/rating/:value', (req, res) => {
  const value = parseFloat(req.params.value);
  Product.find({ rating: { $gt: value } })
    .then((products) => {
      res.json(products);
    })
    .catch((error) => {
      res.status(500).json({ error: error.message });
    });
});

module.exports = router;
