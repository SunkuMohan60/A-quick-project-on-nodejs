const express = require('express');
const router = express.Router();
const User = require('../models/user');
const bcrypt = require('bcrypt');

// Route to register a new user
router.post('/register', (req, res) => {
  const { username, password } = req.body;
  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    const newUser = new User({
      username,
      password: hashedPassword,
    });

    newUser.save()
      .then((user) => {
        res.status(201).json(user);
      })
      .catch((error) => {
        res.status(400).json({ error: error.message });
      });
  });
});

// Route to authenticate and login a user
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  User.findOne({ username })
    .then((user) => {
      if (!user) {
        return res.status(401).json({ message: 'Authentication failed' });
      }

      bcrypt.compare(password, user.password, (err, isMatch) => {
        if (err) {
          return res.status(500).json({ error: err.message });
        }

        if (isMatch) {
          res.json({ message: 'Authentication successful' });
        } else {
          res.status(401).json({ message: 'Authentication failed' });
        }
      });
    })
    .catch((error) => {
      res.status(500).json({ error: error.message });
    });
});

module.exports = router;
