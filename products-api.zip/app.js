// app.js

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const basicAuth = require('basic-auth');
const bcrypt = require('bcrypt');

const app = express();
const port = process.env.PORT || 3000;

// MongoDB connection
mongoose.connect('mongodb://127.0.0.1:27017/products-api?directConnection=true&serverSelectionTimeoutMS=2000', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
mongoose.connection.on('error', (err) => {
  console.error(`MongoDB connection error: ${err}`);
  process.exit(-1);
});

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Models
const User = require('./models/user');
const Product = require('./models/product');

// Function to verify basic authentication credentials
const authenticateUser = async (req, res, next) => {
  const credentials = basicAuth(req);

  if (!credentials) {
    return res.status(401).json({ message: 'Authentication required' });
  }

  const user = await User.findOne({ username: credentials.name });
  console.log(credentials.name);

  if (!user) {
    return res.status(401).json({ message: 'Authentication failed - User Not Found' });
  }

  console.log(credentials.pass);
  console.log(user.password);
  const isMatch = await bcrypt.compare(credentials.pass, user.password);
  console.log(isMatch  );
  if (!isMatch) {
    return res.status(401).json({ message: 'Authentication failed' });
  }

  req.user = user;
  next();
};

// Product routes
app.post('/api/products', authenticateUser, async (req, res) => {
  try {
    const productData = req.body;
    const newProduct = new Product(productData);
    const savedProduct = await newProduct.save();
    res.status(201).json(savedProduct);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/products', authenticateUser, async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/products/:productId', authenticateUser, async (req, res) => {
  try {
    const productId = req.params.productId;
    const updatedProduct = await Product.findByIdAndUpdate(productId, req.body, { new: true });

    if (!updatedProduct) {
      return res.status(404).json({ message: 'Product not found' });
    }

    res.json(updatedProduct);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.delete('/api/products/:productId', authenticateUser, async (req, res) => {
  try {
    const productId = req.params.productId;
    await Product.findByIdAndRemove(productId);

    res.sendStatus(204);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/products/featured', authenticateUser, async (req, res) => {
  try {
    const featuredProducts = await Product.find({ featured: true });
    res.json(featuredProducts);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/products/price/:value', authenticateUser, async (req, res) => {
  try {
    const value = parseFloat(req.params.value);
    const products = await Product.find({ price: { $lt: value } });
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/products/rating/:value', authenticateUser, async (req, res) => {
  try {
    const value = parseFloat(req.params.value);
    const products = await Product.find({ rating: { $gt: value } });
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
